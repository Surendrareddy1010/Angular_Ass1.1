import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

	users = [{name:'surendra',age:67},{name:'naveen',age:20},{name:'goutham',age:50}];

	
 }

